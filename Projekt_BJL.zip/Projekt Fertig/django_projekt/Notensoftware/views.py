from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout


from .models import Lehrer2, Schueler2, MyUser, Unterrichts_Fach, Klasse, Faecher

# Create your views here.

def index(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('Notensoftware:index')
            else:
                return render(request,'Notensoftware/anmeldung.html')
        else:
            return render(request,'Notensoftware/anmeldung.html')
    else:
        if not request.user.is_superuser:
            print(request.user.id)

            try:
                print(request.user.id)
                schueler = Schueler2.objects.get(id=request.user.id)
            except Schueler2.DoesNotExist:
                schueler = None

            try:
                lehrer = Lehrer2.objects.get(id=request.user.id)
            except Lehrer2.DoesNotExist:
                lehrer = None

            if (schueler == None) and (not lehrer == None):
                return redirect('Notensoftware:lehrer')
            if (not schueler == None) and (lehrer == None):
                noten = schueler.noten_set.all()
                return render(request,'Notensoftware/student.html', {'schueler':schueler, 'noten':noten})
        else:
            return redirect('/admin/')

def mylogout(request):
    logout(request)
    return redirect('Notensoftware:index')


def lehrer(request):
    if request.user.is_authenticated:
        lehrer = Lehrer2.objects.get(pk=request.user.id) 
        if not lehrer == None:
            uf = Unterrichts_Fach.objects.filter(l_id=lehrer).values('k_id').distinct()    

            klassen = []
            for klasse in uf:
                klassen.append(Klasse.objects.get(pk=klasse.get('k_id')))

            return render(request,'Notensoftware/teacher.html', {'lehrer':lehrer, 'klassen':klassen})
        else:
            return redirect('Notensoftware:index')
    else:
        return redirect('Notensoftware:index')

def klassenansicht(request, klasse):
    if request.user.is_authenticated:
        lehrer = Lehrer2.objects.get(pk=request.user.id) 
        if not lehrer == None:
            uf = Unterrichts_Fach.objects.filter(l_id=lehrer, k_id=klasse)
            k = Klasse.objects.get(pk=klasse)
        
            faecher = []
            for klasse in uf:
                faecher.append(klasse.f_id)

            return render(request,'Notensoftware/teacher2.html', {'lehrer':lehrer, 'k':k, 'faecher':faecher})
        else:
            return redirect('Notensoftware:index')
    else:
        return redirect('Notensoftware:index')

def fachansicht(request, klasse, fach):
    if request.user.is_authenticated:
        lehrer = Lehrer2.objects.get(pk=request.user.id) 
        if not lehrer == None:
            k = Klasse.objects.get(pk=klasse)
            schueler = k.schueler2_set.all()
            f = Faecher.objects.get(pk=fach)

            return render(request,'Notensoftware/teacher3.html', {'lehrer':lehrer, 'k':k, 'f':f, 'schueler':schueler})
        else:
            return redirect('Notensoftware:index')
    else:
        return redirect('Notensoftware:index')