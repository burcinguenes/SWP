from django.apps import AppConfig


class NotensoftwareConfig(AppConfig):
    name = 'Notensoftware'
